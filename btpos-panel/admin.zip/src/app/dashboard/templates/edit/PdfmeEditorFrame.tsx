"use client";
import { useEffect, useRef } from "react";
import type { PdfmeTemplate, TemplateType } from "@/types/templates";

type Props = {
  template: PdfmeTemplate | null;
  name: string;
  templateType: TemplateType;
  onSave: (t: PdfmeTemplate) => void;
  onDirtyChange?: (dirty: boolean) => void;
};

export function PdfmeEditorFrame({ template, name, templateType, onSave, onDirtyChange }: Props) {
  const ref = useRef<HTMLIFrameElement>(null);
  const loaded = useRef(false);

  useEffect(() => {
    function onMsg(e: MessageEvent) {
      if (e.origin !== window.location.origin || e.source !== ref.current?.contentWindow) return;
      const m = e.data as { type?: string; template?: PdfmeTemplate; dirty?: boolean };
      if (m.type === "btpos:ready" && !loaded.current) {
        loaded.current = true;
        ref.current?.contentWindow?.postMessage(
          { type: "btpos:load", template, meta: { name, templateType } },
          window.location.origin,
        );
      }
      if (m.type === "btpos:save" && m.template) onSave(m.template);
      if (m.type === "btpos:dirty") onDirtyChange?.(!!m.dirty);
    }
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, [template, name, templateType, onSave, onDirtyChange]);

  return (
    <iframe
      ref={ref}
      src="/sablon-editor/index.html"
      style={{ width: "100%", height: "100%", border: 0, background: "#f5f5f5" }}
      title="Şablon editörü"
    />
  );
}
