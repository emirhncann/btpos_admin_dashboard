"use client";

import { useState, useEffect, useCallback } from "react";
import { withAuth } from "@/components/withAuth";
import { apiRequest } from "@/services/api";
import { USER_KEY } from "@/context/AuthContext";

// ─── Tipler ────────────────────────────────────────────────────────────────────
type CashierRole = "cashier" | "manager";

interface Cashier {
  id: string;
  company_id: string;
  full_name: string;
  cashier_code: string;
  role: CashierRole;
  is_active: boolean;
  created_at: string;
  card_number?: string | null;
  allow_all_terminals?: boolean;
  terminal_access_count?: number;
}

interface Terminal {
  id: string;
  terminal_name: string;
  workplace_id: string;
  is_installed: boolean;
}

interface Workplace {
  id: string;
  name: string;
}

interface CashierTerminalAccess {
  terminal_id: string;
  terminals: {
    id: string;
    terminal_name: string;
    workplace_id: string;
    workplaces: { name: string };
  };
}

interface AddForm {
  full_name: string;
  cashier_code: string;
  password: string;
  role: CashierRole;
  card_number: string;
}

type SubmitStatus = "idle" | "submitting" | "success" | "error";

// ─── Sabit ────────────────────────────────────────────────────────────────────
const EMPTY_FORM: AddForm = {
  full_name:    "",
  cashier_code: "",
  password:     "",
  role:         "cashier",
  card_number:  "",
};

// ─── Yardımcı ─────────────────────────────────────────────────────────────────
function getCompanyId(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    const user = JSON.parse(raw) as Record<string, unknown>;
    return user?.company_id != null ? String(user.company_id) : null;
  } catch {
    return null;
  }
}

async function apiFetch<T = unknown>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const res = await apiRequest<T>(endpoint, options);
  return (((res as { data?: unknown }).data ?? res) as unknown) as T;
}

// ─── Badge ────────────────────────────────────────────────────────────────────
function RoleBadge({ role }: { role: CashierRole }) {
  return role === "manager" ? (
    <span className="inline-flex items-center gap-1 text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200 rounded-full px-2.5 py-0.5">
      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
      </svg>
      Yönetici
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-0.5">
      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
      </svg>
      Kasiyer
    </span>
  );
}

function StatusBadge({ active }: { active: boolean }) {
  return active ? (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700">
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
      Aktif
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-400">
      <span className="w-1.5 h-1.5 rounded-full bg-gray-300" />
      Pasif
    </span>
  );
}

// ─── Modal ─────────────────────────────────────────────────────────────────────
function AddCashierModal({
  onClose,
  onSuccess,
  companyId,
}: {
  onClose: () => void;
  onSuccess: () => void;
  companyId: string;
}) {
  const [form, setForm]         = useState<AddForm>(EMPTY_FORM);
  const [showPw, setShowPw]     = useState(false);
  const [status, setStatus]     = useState<SubmitStatus>("idle");
  const [error, setError]       = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<keyof AddForm, string>>>({});

  const set = <K extends keyof AddForm>(k: K) => (v: AddForm[K]) =>
    setForm((p) => ({ ...p, [k]: v }));

  const validate = (): boolean => {
    const errs: Partial<Record<keyof AddForm, string>> = {};
    if (!form.full_name.trim())            errs.full_name    = "Ad Soyad zorunludur.";
    if (!/^\d{6}$/.test(form.cashier_code)) errs.cashier_code = "Tam 6 rakam olmalıdır.";
    if (form.password.length < 4)          errs.password     = "En az 4 karakter giriniz.";
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus("submitting");
    setError(null);

    try {
      const res = await apiRequest("/cashiers/add", {
        method: "POST",
        body: JSON.stringify({
          company_id:   companyId,
          full_name:    form.full_name.trim(),
          cashier_code: form.cashier_code,
          password:     form.password,
          role:         form.role,
          ...(form.card_number.trim() ? { card_number: form.card_number.trim() } : {}),
        }),
      });

      if (res.success === false) {
        setStatus("error");
        setError(res.message ?? "Kasiyer oluşturulamadı.");
        return;
      }

      setStatus("success");
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 800);
    } catch {
      setStatus("error");
      setError("Sunucuya ulaşılamadı.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden">
        {/* Başlık */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
              <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </div>
            <h2 className="text-base font-semibold text-gray-900">Yeni Kasiyer Ekle</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-lg hover:bg-gray-100"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">

          {/* Ad Soyad */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              Ad Soyad <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={form.full_name}
              onChange={(e) => set("full_name")(e.target.value)}
              placeholder="Örn: Ahmet Yılmaz"
              className={`w-full px-3 py-2.5 text-sm border rounded-lg text-gray-800 placeholder-gray-400
                bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all
                ${fieldErrors.full_name ? "border-red-300" : "border-gray-200"}`}
            />
            {fieldErrors.full_name && (
              <p className="mt-1 text-xs text-red-500">{fieldErrors.full_name}</p>
            )}
          </div>

          {/* Kasiyer Kodu + Rol */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Kasiyer Kodu <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={form.cashier_code}
                onChange={(e) => set("cashier_code")(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="123456"
                className={`w-full px-3 py-2.5 text-sm border rounded-lg font-mono text-gray-800 placeholder-gray-400
                  bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all
                  ${fieldErrors.cashier_code ? "border-red-300" : "border-gray-200"}`}
              />
              {fieldErrors.cashier_code ? (
                <p className="mt-1 text-xs text-red-500">{fieldErrors.cashier_code}</p>
              ) : (
                <p className="mt-1 text-xs text-gray-400">Tam 6 rakam</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Rol <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={form.role}
                  onChange={(e) => set("role")(e.target.value as CashierRole)}
                  className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg text-gray-800 bg-white
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all appearance-none pr-8"
                >
                  <option value="cashier">Kasiyer</option>
                  <option value="manager">Yönetici</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2.5">
                  <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
          </div>

          {/* Şifre */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              Şifre <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showPw ? "text" : "password"}
                value={form.password}
                onChange={(e) => set("password")(e.target.value)}
                placeholder="En az 4 karakter"
                className={`w-full px-3 py-2.5 pr-10 text-sm border rounded-lg text-gray-800 placeholder-gray-400
                  bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all
                  ${fieldErrors.password ? "border-red-300" : "border-gray-200"}`}
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors"
              >
                {showPw ? (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                  </svg>
                ) : (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                )}
              </button>
            </div>
            {fieldErrors.password && (
              <p className="mt-1 text-xs text-red-500">{fieldErrors.password}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Kasiyer Kartı (Barkod)
              <span className="ml-1 text-xs text-gray-400 font-normal">— opsiyonel</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={form.card_number}
                onChange={(e) => set("card_number")(e.target.value)}
                placeholder="Barkod okutun veya manuel girin"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
                  focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
              {form.card_number && (
                <button
                  type="button"
                  onClick={() => set("card_number")("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400
                    hover:text-gray-600 text-lg leading-none"
                >
                  ✕
                </button>
              )}
            </div>
            <p className="mt-1 text-xs text-gray-400">
              Kasiyerin barkodlu kartını okutarak otomatik doldurun
            </p>
          </div>

          {/* Genel hata */}
          {status === "error" && error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2.5">
              <svg className="w-4 h-4 text-red-500 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {status === "success" && (
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2.5">
              <svg className="w-4 h-4 text-emerald-500 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <p className="text-sm text-emerald-700 font-medium">Kasiyer başarıyla oluşturuldu.</p>
            </div>
          )}

          {/* Butonlar */}
          <div className="flex items-center justify-end gap-3 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={status === "submitting"}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-lg
                hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={status === "submitting" || status === "success"}
              className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg
                hover:bg-blue-500 active:bg-blue-700 transition-all shadow-sm shadow-blue-600/20
                disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {status === "submitting" ? (
                <>
                  <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Ekleniyor...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Ekle
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── Ana Sayfa ─────────────────────────────────────────────────────────────────
function CashiersPage() {
  const [cashiers, setCashiers]   = useState<Cashier[]>([]);
  const [loading, setLoading]     = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch]       = useState("");
  const [profileModal, setProfileModal]         = useState<{ cashier: Cashier; settings: Record<string, unknown> | null } | null>(null);
  const [profileLoading, setProfileLoading]     = useState(false);
  const [copyModal, setCopyModal]               = useState<Cashier | null>(null);
  const [copyTargets, setCopyTargets]           = useState<string[]>([]);
  const [copyPlu, setCopyPlu]                   = useState(false);
  const [copying, setCopying]                   = useState(false);
  const [copyResult, setCopyResult]             = useState<{ ok: boolean; text: string } | null>(null);
  const [editingCard, setEditingCard]           = useState<string | null>(null);
  const [cardInput, setCardInput]               = useState("");
  const [savingCard, setSavingCard]             = useState(false);
  const [terminals, setTerminals]               = useState<Terminal[]>([]);
  const [workplaces, setWorkplaces]             = useState<Workplace[]>([]);
  const [accessModal, setAccessModal]           = useState<{
    cashier: Cashier;
    allowAll: boolean;
    selectedIds: string[];
    originalIds: string[];
    saving: boolean;
  } | null>(null);
  const [accessCounts, setAccessCounts]         = useState<Record<string, number>>({});

  const companyId = getCompanyId();

  const fetchCashiers = useCallback(async () => {
    if (!companyId) { setLoading(false); return; }
    setLoading(true);
    setFetchError(null);
    try {
      const res = await apiRequest<Cashier[]>(`/cashiers/${companyId}`);
      const list = (res.data ?? res) as unknown as Cashier[];
      setCashiers(Array.isArray(list) ? list : []);
    } catch {
      setFetchError("Kasiyerler yüklenemedi.");
    } finally {
      setLoading(false);
    }
  }, [companyId]);

  useEffect(() => { void fetchCashiers(); }, [fetchCashiers]);

  useEffect(() => {
    if (!companyId) return;
    void Promise.all([
      apiFetch<Terminal[]>(`/management/licenses/terminals/${companyId}`),
      apiFetch<Workplace[]>(`/workplaces/${companyId}`),
    ]).then(([termData, wpData]) => {
      setTerminals((Array.isArray(termData) ? termData : []).filter((t) => t.is_installed));
      setWorkplaces(Array.isArray(wpData) ? wpData : []);
    }).catch(() => {
      setTerminals([]);
      setWorkplaces([]);
    });
  }, [companyId]);

  const filtered = cashiers.filter((c) =>
    c.full_name.toLowerCase().includes(search.toLowerCase()) ||
    c.cashier_code.includes(search)
  );

  async function openAccessModal(cashier: Cashier) {
    if (!companyId) return;
    try {
      const data = await apiFetch<CashierTerminalAccess[]>(
        `/cashiers/${companyId}/${cashier.id}/terminals`
      );
      const ids = (Array.isArray(data) ? data : []).map((d) => d.terminal_id);
      setAccessCounts((prev) => ({ ...prev, [cashier.id]: ids.length }));
      setAccessModal({
        cashier,
        allowAll: cashier.allow_all_terminals ?? true,
        selectedIds: ids,
        originalIds: ids,
        saving: false,
      });
    } catch {
      setAccessModal({
        cashier,
        allowAll: cashier.allow_all_terminals ?? true,
        selectedIds: [],
        originalIds: [],
        saving: false,
      });
    }
  }

  async function saveAccess() {
    if (!accessModal || !companyId) return;
    setAccessModal((m) => (m ? { ...m, saving: true } : m));
    try {
      await apiFetch(`/cashiers/${companyId}/${accessModal.cashier.id}/terminals`, {
        method: "PUT",
        body: JSON.stringify({
          allow_all_terminals: accessModal.allowAll,
          terminal_ids: accessModal.selectedIds,
        }),
      });
      setAccessCounts((prev) => ({
        ...prev,
        [accessModal.cashier.id]: accessModal.selectedIds.length,
      }));
      setAccessModal(null);
      void fetchCashiers();
    } catch {
      setAccessModal((m) => (m ? { ...m, saving: false } : m));
      setFetchError("Kasa erişimi kaydedilemedi.");
    }
  }

  async function viewProfile(cashier: Cashier) {
    setProfileLoading(true);
    setProfileModal({ cashier, settings: null });
    try {
      const data = await apiFetch<Record<string, unknown>>(
        `/pos-settings/resolve?cashier_id=${cashier.id}&company_id=${companyId}`
      );
      setProfileModal({ cashier, settings: data });
    } catch {
      setProfileModal({ cashier, settings: null });
    } finally {
      setProfileLoading(false);
    }
  }

  async function copyProfile() {
    if (!copyModal || copyTargets.length === 0) return;
    setCopying(true);
    setCopyResult(null);
    try {
      const data = await apiFetch<{ success?: boolean; copied?: number; message?: string }>(
        "/cashiers/copy-profile",
        {
          method: "POST",
          body: JSON.stringify({
            source_cashier_id:  copyModal.id,
            target_cashier_ids: copyTargets,
            copy_settings:      true,
            copy_plu:           copyPlu,
          }),
        }
      );
      if (data.success) {
        setCopyResult({ ok: true,  text: `${data.copied} kasiyere kopyalandı ✓` });
        setCopyTargets([]);
      } else {
        setCopyResult({ ok: false, text: data.message ?? "Kopyalama başarısız." });
      }
    } catch {
      setCopyResult({ ok: false, text: "Sunucuya ulaşılamadı." });
    } finally {
      setCopying(false);
    }
  }

  async function saveCard(cashierId: string) {
    setSavingCard(true);
    try {
      await apiRequest(`/cashiers/${cashierId}`, {
        method: "PATCH",
        body: JSON.stringify({ card_number: cardInput.trim() || null }),
      });
      setEditingCard(null);
      setCardInput("");
      await fetchCashiers();
    } catch {
      setFetchError("Kart bilgisi güncellenemedi.");
    } finally {
      setSavingCard(false);
    }
  }

  return (
    <div className="space-y-6">
      {profileModal && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 9999,
          background: "rgba(0,0,0,0.4)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <div style={{
            background: "white", borderRadius: 14, padding: 24, width: 440,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontWeight: 600, fontSize: 15 }}>
                {profileModal.cashier.full_name} — Profil
              </div>
              <button onClick={() => setProfileModal(null)}
                style={{ background: "none", border: "none", cursor: "pointer", fontSize: 20, color: "#9E9E9E" }}>✕</button>
            </div>

            {profileLoading ? (
              <div style={{ textAlign: "center", color: "#9ca3af", padding: "24px 0" }}>Yükleniyor...</div>
            ) : profileModal.settings ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {[
                  { label: "Kaynak",         value: String(profileModal.settings.source ?? "—") },
                  { label: "Satır İsk.",     value: profileModal.settings.allow_line_discount ? `Açık (max %${profileModal.settings.max_line_discount_pct})` : "Kapalı" },
                  { label: "Belge İsk.",     value: profileModal.settings.allow_doc_discount  ? `Açık (max %${profileModal.settings.max_doc_discount_pct})`  : "Kapalı" },
                  { label: "PLU Izgara",     value: `${profileModal.settings.plu_cols ?? 4} × ${profileModal.settings.plu_rows ?? 3}` },
                  { label: "PLU Modu",       value: profileModal.settings.plu_mode === "cashier" ? "Kasiyer Bazlı" : "Kasa Bazlı" },
                ].map(row => (
                  <div key={row.label} style={{
                    display: "flex", justifyContent: "space-between",
                    padding: "8px 12px", borderRadius: 8, background: "#F9FAFB",
                  }}>
                    <span style={{ fontSize: 13, color: "#6B7280" }}>{row.label}</span>
                    <span style={{ fontSize: 13, fontWeight: 500, color: "#111" }}>{row.value}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ textAlign: "center", color: "#9ca3af", padding: "24px 0", fontSize: 13 }}>
                Bu kasiyer için özel ayar yok — kasa/firma ayarı geçerli
              </div>
            )}

            <button
              onClick={() => {
                setProfileModal(null);
                setCopyModal(profileModal.cashier);
                setCopyTargets([]);
                setCopyResult(null);
              }}
              style={{
                marginTop: 16, width: "100%", padding: "10px", borderRadius: 9,
                background: "#EFF6FF", border: "1px solid #C7D7FD",
                color: "#1D4ED8", cursor: "pointer", fontSize: 13, fontWeight: 600,
              }}
            >
              Bu Profili Kopyala →
            </button>
          </div>
        </div>
      )}

      {copyModal && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 9998,
          background: "rgba(0,0,0,0.4)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <div style={{
            background: "white", borderRadius: 14, padding: 24, width: 480,
            maxHeight: "80vh", display: "flex", flexDirection: "column", gap: 16,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div style={{ fontWeight: 600, fontSize: 15 }}>
                "{copyModal.full_name}" profilini kopyala
              </div>
              <button onClick={() => { setCopyModal(null); setCopyResult(null); }}
                style={{ background: "none", border: "none", cursor: "pointer", fontSize: 20, color: "#9E9E9E" }}>✕</button>
            </div>

            <div style={{ fontSize: 12, color: "#6B7280" }}>
              Hedef kasiyerleri seç (birden fazla seçilebilir):
            </div>

            <div style={{ overflowY: "auto", flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
              {cashiers
                .filter(c => c.id !== copyModal.id)
                .map(c => {
                  const isSelected = copyTargets.includes(c.id);
                  return (
                    <div
                      key={c.id}
                      onClick={() => setCopyTargets(prev =>
                        isSelected ? prev.filter(id => id !== c.id) : [...prev, c.id]
                      )}
                      style={{
                        padding: "10px 14px", borderRadius: 8, cursor: "pointer",
                        border: `1.5px solid ${isSelected ? "#1D4ED8" : "#E5E7EB"}`,
                        background: isSelected ? "#EFF6FF" : "white",
                        display: "flex", alignItems: "center", gap: 8,
                      }}
                    >
                      <span style={{
                        width: 16, height: 16, borderRadius: 4, flexShrink: 0,
                        background: isSelected ? "#1D4ED8" : "white",
                        border: `2px solid ${isSelected ? "#1D4ED8" : "#D1D5DB"}`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                      }}>
                        {isSelected && <span style={{ color: "white", fontSize: 10 }}>✓</span>}
                      </span>
                      <span style={{ fontSize: 13, color: isSelected ? "#1D4ED8" : "#374151", fontWeight: isSelected ? 600 : 400 }}>
                        {c.full_name}
                      </span>
                      <span style={{ fontSize: 11, color: "#9ca3af", marginLeft: "auto", fontFamily: "monospace" }}>
                        {c.cashier_code}
                      </span>
                    </div>
                  );
                })}
            </div>

            <div style={{
              display: "flex", alignItems: "center", gap: 10,
              padding: "10px 0", borderTop: "1px solid #F0F0F0",
            }}>
              <input
                type="checkbox"
                id="copyPlu"
                checked={copyPlu}
                onChange={e => setCopyPlu(e.target.checked)}
              />
              <label htmlFor="copyPlu" style={{ fontSize: 13, color: "#374151", cursor: "pointer" }}>
                PLU gruplarını da kopyala
              </label>
            </div>

            {copyResult && (
              <div style={{
                padding: "10px 14px", borderRadius: 8, fontSize: 13,
                background: copyResult.ok ? "#F0FDF4" : "#FEF2F2",
                border: `1px solid ${copyResult.ok ? "#BBF7D0" : "#FECACA"}`,
                color: copyResult.ok ? "#166534" : "#991B1B",
              }}>
                {copyResult.text}
              </div>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button
                onClick={() => { setCopyModal(null); setCopyResult(null); }}
                style={{
                  flex: 1, padding: "11px", borderRadius: 9,
                  border: "1px solid #E0E0E0", background: "white",
                  cursor: "pointer", fontSize: 13, color: "#374151",
                }}
              >
                İptal
              </button>
              <button
                onClick={() => void copyProfile()}
                disabled={copyTargets.length === 0 || copying}
                style={{
                  flex: 2, padding: "11px", borderRadius: 9, border: "none",
                  background: copyTargets.length > 0 && !copying ? "#1D4ED8" : "#E5E7EB",
                  color: copyTargets.length > 0 && !copying ? "white" : "#9ca3af",
                  cursor: copyTargets.length > 0 && !copying ? "pointer" : "default",
                  fontSize: 13, fontWeight: 600,
                }}
              >
                {copying
                  ? "Kopyalanıyor..."
                  : copyTargets.length > 0
                    ? `${copyTargets.length} kasiyere kopyala`
                    : "Kasiyer seçin"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Başlık ── */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Kasiyerler</h1>
          <p className="text-sm text-gray-500 mt-1">
            POS terminallerine erişim sağlayan kasiyer hesaplarını yönetin.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowModal(true)}
          disabled={!companyId}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-semibold rounded-lg
            hover:bg-blue-500 active:bg-blue-700 transition-all shadow-sm shadow-blue-600/20
            disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Yeni Kasiyer
        </button>
      </div>

      {/* ── company_id yoksa uyarı ── */}
      {!companyId && (
        <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
          <svg className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
          <p className="text-xs text-amber-700">
            Oturumunuzda <strong>company_id</strong> bulunamadı. Lütfen tekrar giriş yapınız.
          </p>
        </div>
      )}

      {/* ── Tablo Kartı ── */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">

        {/* Arama + sayaç */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-4">
          <div className="relative w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="İsim veya kod ara…"
              className="w-full pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-lg bg-white text-gray-800
                placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
            />
          </div>
          {!loading && (
            <span className="text-xs text-gray-400 shrink-0">
              {filtered.length} / {cashiers.length} kasiyer
            </span>
          )}
        </div>

        {/* İçerik */}
        {loading ? (
          <div className="divide-y divide-gray-50">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="px-5 py-4 flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-gray-200 animate-pulse shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-3.5 w-36 bg-gray-200 rounded animate-pulse" />
                  <div className="h-3 w-20 bg-gray-100 rounded animate-pulse" />
                </div>
                <div className="h-5 w-16 bg-gray-100 rounded-full animate-pulse" />
              </div>
            ))}
          </div>
        ) : fetchError ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center">
            <svg className="w-8 h-8 text-red-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-sm text-red-500 font-medium">{fetchError}</p>
            <button
              type="button"
              onClick={fetchCashiers}
              className="text-xs text-blue-500 hover:text-blue-700 transition-colors font-medium"
            >
              Yeniden dene
            </button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-16 text-center">
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">
                {search ? "Aramanızla eşleşen kasiyer bulunamadı." : "Henüz kasiyer eklenmemiş."}
              </p>
              {!search && (
                <p className="text-xs text-gray-400 mt-1">
                  Yukarıdaki &quot;Yeni Kasiyer&quot; butonuyla ilk kasiyeri oluşturun.
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50/60 border-b border-gray-100">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Kasiyer</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Kod</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Rol</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Durum</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Oluşturulma</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0
                          ${c.role === "manager" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"}`}>
                          {c.full_name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <span className="font-medium text-gray-900">{c.full_name}</span>
                          <div>
                            <span style={{ fontSize: 10, color: "#9CA3AF" }}>
                              {c.allow_all_terminals !== false
                                ? "Tüm kasalar"
                                : `${accessCounts[c.id] ?? c.terminal_access_count ?? 0} kasa`}
                            </span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="font-mono text-sm text-gray-700 bg-gray-100 rounded px-2 py-0.5">{c.cashier_code}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <RoleBadge role={c.role} />
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <StatusBadge active={c.is_active} />
                        {c.card_number ? (
                          <span className="inline-flex items-center gap-1 text-xs font-medium bg-green-50 text-green-700 border border-green-200 rounded-full px-2 py-0.5">
                            🏷️ Kart Atandı
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs font-medium text-gray-400 border border-gray-200 rounded-full px-2 py-0.5">
                            Kart Yok
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs text-gray-400">
                      {new Date(c.created_at).toLocaleDateString("tr-TR", {
                        day: "2-digit", month: "short", year: "numeric",
                      })}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          onClick={() => void viewProfile(c)}
                          style={{
                            fontSize: 11, padding: "4px 10px", borderRadius: 6,
                            border: "1px solid #E0E0E0", background: "white",
                            color: "#374151", cursor: "pointer",
                          }}
                        >
                          Profil
                        </button>
                        <button
                          onClick={() => { setCopyModal(c); setCopyResult(null); setCopyTargets([]); }}
                          style={{
                            fontSize: 11, padding: "4px 10px", borderRadius: 6,
                            border: "1px solid #C7D7FD", background: "#EFF6FF",
                            color: "#1D4ED8", cursor: "pointer",
                          }}
                        >
                          Kopyala
                        </button>
                        <button
                          onClick={() => void openAccessModal(c)}
                          style={{
                            padding: "5px 10px",
                            borderRadius: 6,
                            border: "1px solid #E5E7EB",
                            background: "#F9FAFB",
                            fontSize: 11,
                            color: "#374151",
                            cursor: "pointer",
                          }}
                        >
                          🖥 Kasa Erişimi
                        </button>
                      </div>
                      {editingCard === c.id ? (
                        <div className="flex items-center gap-2 mt-2">
                          <input
                            autoFocus
                            type="text"
                            value={cardInput}
                            onChange={(e) => setCardInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") void saveCard(c.id);
                              if (e.key === "Escape") {
                                setEditingCard(null);
                                setCardInput("");
                              }
                            }}
                            placeholder="Barkod okutun..."
                            className="flex-1 text-sm border border-blue-300 rounded px-2 py-1
                              font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                          <button
                            onClick={() => void saveCard(c.id)}
                            disabled={savingCard}
                            className="text-xs bg-blue-600 text-white px-3 py-1 rounded
                              hover:bg-blue-700 disabled:opacity-50"
                          >
                            {savingCard ? "..." : "Kaydet"}
                          </button>
                          {c.card_number && (
                            <button
                              onClick={() => {
                                setCardInput("");
                                void saveCard(c.id);
                              }}
                              className="text-xs text-red-500 hover:text-red-700 px-2 py-1"
                            >
                              Kartı Kaldır
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setEditingCard(null);
                              setCardInput("");
                            }}
                            className="text-xs text-gray-400 hover:text-gray-600"
                          >
                            İptal
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setEditingCard(c.id);
                            setCardInput(c.card_number ?? "");
                          }}
                          className="text-xs text-blue-600 hover:text-blue-800 mt-1"
                        >
                          {c.card_number ? "✏️ Kartı Düzenle" : "+ Kart Ata"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── Modal ── */}
      {showModal && companyId && (
        <AddCashierModal
          companyId={companyId}
          onClose={() => setShowModal(false)}
          onSuccess={fetchCashiers}
        />
      )}

      {accessModal && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 9999,
          background: "rgba(0,0,0,0.45)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <div style={{
            background: "white", borderRadius: 16, padding: 24,
            width: "min(520px, 95vw)", maxHeight: "85vh",
            display: "flex", flexDirection: "column", gap: 14,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Kasa Erişimi</div>
                <div style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>
                  {accessModal.cashier.full_name} · {accessModal.cashier.cashier_code}
                </div>
              </div>
              <button type="button" onClick={() => setAccessModal(null)}
                style={{ background: "none", border: "none", fontSize: 20,
                  color: "#9CA3AF", cursor: "pointer" }}>✕</button>
            </div>

            <div
              onClick={() => setAccessModal((m) => (m ? { ...m, allowAll: !m.allowAll } : m))}
              style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                padding: "12px 14px", borderRadius: 10,
                border: `1.5px solid ${accessModal.allowAll ? "#BFDBFE" : "#E5E7EB"}`,
                background: accessModal.allowAll ? "#EFF6FF" : "#F9FAFB",
                cursor: "pointer",
              }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600,
                  color: accessModal.allowAll ? "#1565C0" : "#374151" }}>
                  Tüm Kasalara Erişim
                </div>
                <div style={{ fontSize: 11, color: "#6B7280", marginTop: 2 }}>
                  {accessModal.allowAll
                    ? "Bu kasiyer tüm kasalarda giriş yapabilir"
                    : "Sadece seçili kasalarda giriş yapabilir"}
                </div>
              </div>
              <div style={{
                width: 42, height: 24, borderRadius: 12,
                background: accessModal.allowAll ? "#1565C0" : "#E5E7EB",
                position: "relative", transition: "background 0.2s", flexShrink: 0,
              }}>
                <div style={{
                  position: "absolute", top: 3, width: 18, height: 18,
                  borderRadius: "50%", background: "white",
                  left: accessModal.allowAll ? 21 : 3, transition: "left 0.2s",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                }} />
              </div>
            </div>

            {!accessModal.allowAll && (
              <div style={{ flex: 1, overflowY: "auto" }}>
                <div style={{ fontSize: 11, color: "#6B7280", marginBottom: 8, fontWeight: 600 }}>
                  Erişim Verilecek Kasalar
                </div>

                {workplaces.map((wp) => {
                  const wpTerminals = terminals.filter((t) => t.workplace_id === wp.id);
                  if (wpTerminals.length === 0) return null;
                  return (
                    <div key={wp.id} style={{ marginBottom: 12 }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: "#374151",
                        padding: "4px 0", borderBottom: "1px solid #F3F4F6",
                        marginBottom: 6 }}>
                        📍 {wp.name}
                      </div>
                      {wpTerminals.map((t) => {
                        const checked = accessModal.selectedIds.includes(t.id);
                        return (
                          <div
                            key={t.id}
                            onClick={() => setAccessModal((m) => {
                              if (!m) return m;
                              const ids = checked
                                ? m.selectedIds.filter((id) => id !== t.id)
                                : [...m.selectedIds, t.id];
                              return { ...m, selectedIds: ids };
                            })}
                            style={{
                              display: "flex", alignItems: "center", gap: 10,
                              padding: "8px 10px", borderRadius: 8, cursor: "pointer",
                              marginBottom: 4,
                              background: checked ? "#F0FDF4" : "white",
                              border: `1px solid ${checked ? "#86EFAC" : "#E5E7EB"}`,
                            }}>
                            <div style={{
                              width: 18, height: 18, borderRadius: 4, flexShrink: 0,
                              border: `2px solid ${checked ? "#10B981" : "#D1D5DB"}`,
                              background: checked ? "#10B981" : "white",
                              display: "flex", alignItems: "center", justifyContent: "center",
                            }}>
                              {checked && <span style={{ color: "white", fontSize: 11 }}>✓</span>}
                            </div>
                            <span style={{ fontSize: 13, color: "#374151" }}>
                              🖥 {t.terminal_name}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  );
                })}

                {terminals.length === 0 && (
                  <div style={{ textAlign: "center", color: "#9CA3AF",
                    padding: "24px 0", fontSize: 12 }}>
                    Kurulu kasa bulunamadı
                  </div>
                )}
              </div>
            )}

            <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
              <button type="button" onClick={() => setAccessModal(null)}
                style={{ flex: 1, padding: "10px", borderRadius: 9,
                  border: "1px solid #E5E7EB", background: "#F9FAFB",
                  fontSize: 13, cursor: "pointer", color: "#6B7280" }}>
                İptal
              </button>
              <button
                type="button"
                onClick={() => void saveAccess()}
                disabled={accessModal.saving}
                style={{ flex: 2, padding: "10px", borderRadius: 9,
                  border: "none", background: "#111827",
                  color: "white", fontWeight: 700, fontSize: 13,
                  cursor: "pointer", opacity: accessModal.saving ? 0.7 : 1 }}>
                {accessModal.saving ? "Kaydediliyor..." : "Kaydet"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default withAuth(CashiersPage);
