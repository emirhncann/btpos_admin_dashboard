"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { API_ERROR_EVENT } from "@/services/api";

const BRAND = {
  sidebarBg: "#3A0B05",
  activeBg: "#C21807",
  accentBg: "#FF2A1A",
  textMuted: "#F3C7C2",
};

interface NavItem {
  href: string;
  label: string;
  icon: React.ReactNode;
}

const NAV_ITEMS: NavItem[] = [
  {
    href: "/dashboard",
    label: "Gösterge Paneli",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
        />
      </svg>
    ),
  },
  {
    href: "/dashboard/workplaces",
    label: "Şubeler",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
      </svg>
    ),
  },
  {
    href: "/dashboard/terminals",
    label: "Kasa Yönetimi",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
        />
      </svg>
    ),
  },
  {
    href: "/dashboard/templates",
    label: "Şablonlar",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
        />
      </svg>
    ),
  },
  {
    href: "/dashboard/updates",
    label: "Kasaları Güncelle",
    icon: "☁ ",
  },
  {
    href: "/dashboard/customer-changes",
    label: "Müşteri Değişiklikleri",
    icon: "👤",
  },
  {
    href: "/dashboard/day-end",
    label: "Gün Sonu",
    icon: "📅",
  },
  {
    href: "/dashboard/pos-settings",
    label: "POS Ayarları",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
        />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
  {
    href: "/dashboard/unit-mappings",
    label: "Birim Eşleme",
    icon: "⚖️",
  },
  {
    href: "/dashboard/payment-accounts",
    label: "Ödeme Hesapları",
    icon: "💳",
  },
  {
    href: "/dashboard/plu",
    label: "PLU Yönetimi",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
        />
      </svg>
    ),
  },
  {
    href: "/dashboard/cashiers",
    label: "Kasiyerler",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"
        />
      </svg>
    ),
  },
  {
    href: "/dashboard/store-users",
    label: "Mağaza Kullanıcıları",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M3 9l1-5h16l1 5M3 9h18M3 9v1a3 3 0 006 0V9m0 0v1a3 3 0 006 0V9m0 0v1a3 3 0 006 0V9M5 13v7h14v-7"
        />
      </svg>
    ),
  },
  {
    href: "/dashboard/erp-settings",
    label: "ERP Entegrasyon",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
          d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"
        />
      </svg>
    ),
  },
];

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  useEffect(() => {
    const onError = (event: Event) => {
      const message = (event as CustomEvent<{ message?: string }>).detail?.message;
      if (message) setApiError(message);
    };
    window.addEventListener(API_ERROR_EVENT, onError);
    return () => window.removeEventListener(API_ERROR_EVENT, onError);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside
        className={`${collapsed ? "w-20" : "w-64"} text-white flex flex-col shrink-0 transition-all duration-200 overflow-hidden`}
        style={{ background: BRAND.sidebarBg }}
      >
        {/* Logo */}
        <div className={`${collapsed ? "px-3 py-4" : "px-6 py-5"} border-b border-white/10`}>
          <div className={`relative flex items-center ${collapsed ? "justify-center" : "gap-3"}`}>
            <div className="w-12 h-12  flex items-center justify-center shrink-0 overflow-hidden p-1">
              <img
                src="/branding/logo_icon_whitebg.png"
                alt="BTPOS Logo"
                className={`${collapsed ? "w-8 h-8" : "w-10 h-10"} object-contain`}
              />
            </div>
            {!collapsed && (
              <div>
                <p className="text-sm font-bold">BTPOS</p>
                <p className="text-xs" style={{ color: BRAND.textMuted }}>Yönetici Konsolu</p>
              </div>
            )}
            <button
              type="button"
              onClick={() => setCollapsed((v) => !v)}
              className={`${collapsed ? "absolute -right-0.5 -bottom-1" : "ml-auto"} text-slate-300 hover:text-white p-1 rounded hover:bg-white/10`}
              aria-label={collapsed ? "Sidebar aç" : "Sidebar kapat"}
              title={collapsed ? "Aç" : "Kapat"}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {collapsed ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Nav */}
        <nav className={`${collapsed ? "px-2" : "px-3"} py-4 space-y-1 overflow-y-auto`}>
          {NAV_ITEMS.map((item) => {
            const isActive =
              item.href === "/dashboard"
                ? pathname === "/dashboard" || pathname === "/dashboard/"
                : pathname.startsWith(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                title={collapsed ? item.label : undefined}
                className={`flex items-center ${collapsed ? "justify-center w-10 h-10 mx-auto px-0 py-0" : "gap-3 px-3 py-2"} rounded-lg text-sm transition-colors ${
                  isActive
                    ? "text-white"
                    : "text-slate-400 hover:bg-white/5 hover:text-white"
                }`}
                style={isActive ? { background: BRAND.activeBg } : undefined}
              >
                {item.icon}
                {!collapsed && item.label}
              </Link>
            );
          })}
        </nav>

        {/* Kullanıcı */}
        <div className={`${collapsed ? "px-2" : "px-3"} py-4 border-t border-white/10`}>
          <div className={`flex ${collapsed ? "flex-col items-center gap-2" : "items-center gap-3"} px-3 py-2 rounded-lg`}>
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold uppercase shrink-0"
              style={{ background: BRAND.accentBg }}
            >
              {user?.name?.charAt(0) ?? "A"}
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.name ?? "Admin"}</p>
                <p className="text-xs truncate" style={{ color: BRAND.textMuted }}>{user?.email ?? ""}</p>
              </div>
            )}
            <button
              type="button"
              onClick={logout}
              title="Çıkış Yap"
              className="text-slate-500 hover:text-red-400 transition shrink-0"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                />
              </svg>
            </button>
          </div>
        </div>
      </aside>

      {/* İçerik */}
      <main className="flex-1 overflow-y-auto">
        <div className="p-8" style={{ background: "#F8FAFC", minHeight: "100%" }}>
          {apiError && (
            <div style={{
              marginBottom: 16, padding: "12px 16px", borderRadius: 8, fontSize: 13, fontWeight: 600,
              background: "#FEF2F2", border: "1px solid #FECACA", color: "#991B1B",
              display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center",
            }}>
              <span>{apiError}</span>
              <button type="button" onClick={() => setApiError(null)} style={{
                border: "none", background: "transparent", color: "#991B1B", cursor: "pointer", fontWeight: 700,
              }}>Kapat</button>
            </div>
          )}
          {children}
        </div>
      </main>
    </div>
  );
}
