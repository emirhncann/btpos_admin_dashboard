"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { withAuth } from "@/components/withAuth";
import { USER_KEY } from "@/context/AuthContext";
import { apiRequest, sendCommand } from "@/services/api";

interface Customer {
  id: string;
  code: string;
  name: string;
  taxNo: string;
  taxOffice: string;
  phone: string;
  email: string;
  city: string;
  district: string;
  isPerson: boolean;
}

interface AddCustomerForm {
  isPerson: boolean;
  name: string;
  code: string;
  taxNo: string;
  taxOffice: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  district: string;
  postalCode: string;
}

const EMPTY_FORM: AddCustomerForm = {
  isPerson: true,
  name: "",
  code: "",
  taxNo: "",
  taxOffice: "",
  phone: "",
  email: "",
  address: "",
  city: "",
  district: "",
  postalCode: "",
};

function getCompanyId(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    const user = JSON.parse(raw) as Record<string, unknown>;
    return user?.company_id != null ? String(user.company_id) : null;
  } catch {
    return null;
  }
}

function mapCustomerRow(row: Record<string, unknown>, idx: number): Customer {
  const code = String(
    row.code ?? row.customer_code ?? row.Code ?? row.id ?? `ROW-${idx + 1}`
  ).trim();
  const name = String(row.name ?? row.Name ?? row.title ?? row.unvan ?? "").trim();
  const taxNo = String(
    row.taxNo ?? row.tax_no ?? row.tcKimlikNo ?? row.vkn ?? row.tax_number ?? ""
  ).trim();
  const taxOffice = String(
    row.taxOffice ?? row.tax_office ?? row.vergiDairesi ?? ""
  ).trim();
  const phone = String(row.phone ?? row.telephone ?? row.mobile ?? "").trim();
  const email = String(row.email ?? row.mail ?? "").trim();
  const city = String(row.city ?? row.il ?? "").trim();
  const district = String(row.district ?? row.ilce ?? "").trim();
  const rawIsPerson = row.isPerson ?? row.is_person;
  return {
    id: String(row.id ?? code ?? `row-${idx}`),
    code,
    name,
    taxNo,
    taxOffice,
    phone,
    email,
    city,
    district,
    isPerson: rawIsPerson == null ? true : Boolean(rawIsPerson),
  };
}

function parseCustomersPayload(payload: unknown): Customer[] {
  const base =
    payload && typeof payload === "object" && "data" in payload
      ? (payload as { data?: unknown }).data
      : payload;

  const list =
    base && typeof base === "object" && "data" in base && Array.isArray((base as { data?: unknown }).data)
      ? ((base as { data: unknown[] }).data as unknown[])
      : Array.isArray(base)
        ? base
        : base && typeof base === "object" && Array.isArray((base as { customers?: unknown }).customers)
          ? ((base as { customers: unknown[] }).customers as unknown[])
          : [];

  return list
    .map((row, idx) =>
      row && typeof row === "object"
        ? mapCustomerRow(row as Record<string, unknown>, idx)
        : null
    )
    .filter((row): row is Customer => row !== null)
    .filter((row) => row.name.length > 0 || row.code.length > 0);
}

function AddCustomerModal({
  companyId,
  onClose,
  onSuccess,
}: {
  companyId: string;
  onClose: () => void;
  onSuccess: () => Promise<void>;
}) {
  const [form, setForm] = useState<AddCustomerForm>(EMPTY_FORM);
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<keyof AddCustomerForm, string>>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const set = <K extends keyof AddCustomerForm>(key: K, value: AddCustomerForm[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  function validate(): boolean {
    const errs: Partial<Record<keyof AddCustomerForm, string>> = {};
    if (!form.name.trim()) errs.name = "Ad Soyad / Firma Adı zorunludur.";
    if (!form.taxNo.trim()) errs.taxNo = form.isPerson ? "TC Kimlik No zorunludur." : "VKN zorunludur.";
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    setSubmitError(null);
    try {
      const res = await apiRequest<{ success?: boolean; message?: string }>(
        `/integration/customers/${companyId}`,
        {
          method: "POST",
          body: JSON.stringify({
            isPerson: form.isPerson,
            name: form.name.trim(),
            code: form.code.trim(),
            taxNo: form.taxNo.trim(),
            taxOffice: form.taxOffice.trim(),
            phone: form.phone.trim(),
            email: form.email.trim(),
            address: form.address.trim(),
            city: form.city.trim(),
            district: form.district.trim(),
            postalCode: form.postalCode.trim(),
          }),
        }
      );

      if (res.success === false) {
        setSubmitError(res.message ?? "Müşteri oluşturulamadı.");
        return;
      }

      await onSuccess();
      onClose();
    } catch {
      setSubmitError("Sunucuya ulaşılamadı.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4">
          <h2 className="text-base font-semibold text-gray-900">Yeni Müşteri / Cari Ekle</h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
            aria-label="Kapat"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 px-6 py-5">
          <div>
            <p className="mb-2 block text-sm font-medium text-gray-700">Müşteri Tipi</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => set("isPerson", true)}
                className={`rounded-lg border px-3 py-2 text-sm font-medium ${
                  form.isPerson
                    ? "border-blue-300 bg-blue-50 text-blue-700"
                    : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                }`}
              >
                Bireysel
              </button>
              <button
                type="button"
                onClick={() => set("isPerson", false)}
                className={`rounded-lg border px-3 py-2 text-sm font-medium ${
                  !form.isPerson
                    ? "border-blue-300 bg-blue-50 text-blue-700"
                    : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                }`}
              >
                Kurumsal
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="mb-1.5 block text-sm font-medium text-gray-700">
                {form.isPerson ? "Ad Soyad" : "Firma Adı"} <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
                className={`w-full rounded-lg border px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  fieldErrors.name ? "border-red-300" : "border-gray-200"
                }`}
                placeholder={form.isPerson ? "Örn: Ahmet Yılmaz" : "Örn: ACME Ltd. Şti."}
              />
              {fieldErrors.name && <p className="mt-1 text-xs text-red-500">{fieldErrors.name}</p>}
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">Müşteri Kodu</label>
              <input
                type="text"
                value={form.code}
                onChange={(e) => set("code", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="KOD001"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">
                {form.isPerson ? "TC Kimlik No" : "VKN"} <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={form.taxNo}
                onChange={(e) => set("taxNo", e.target.value)}
                className={`w-full rounded-lg border px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  fieldErrors.taxNo ? "border-red-300" : "border-gray-200"
                }`}
                placeholder={form.isPerson ? "11111111111" : "1234567890"}
              />
              {fieldErrors.taxNo && <p className="mt-1 text-xs text-red-500">{fieldErrors.taxNo}</p>}
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">Vergi Dairesi</label>
              <input
                type="text"
                value={form.taxOffice}
                onChange={(e) => set("taxOffice", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Bolu"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">Telefon</label>
              <input
                type="text"
                value={form.phone}
                onChange={(e) => set("phone", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0555..."
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">E-posta</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="a@b.com"
              />
            </div>

            <div className="col-span-2">
              <label className="mb-1.5 block text-sm font-medium text-gray-700">Adres</label>
              <input
                type="text"
                value={form.address}
                onChange={(e) => set("address", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Adres"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">Şehir</label>
              <input
                type="text"
                value={form.city}
                onChange={(e) => set("city", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Bolu"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">İlçe</label>
              <input
                type="text"
                value={form.district}
                onChange={(e) => set("district", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Merkez"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">Posta Kodu</label>
              <input
                type="text"
                value={form.postalCode}
                onChange={(e) => set("postalCode", e.target.value)}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="14100"
              />
            </div>
          </div>

          {submitError && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
              {submitError}
            </div>
          )}

          <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50"
            >
              {submitting ? "Kaydediliyor..." : "Kaydet"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);
  const companyId = getCompanyId();

  const fetchCustomers = useCallback(async () => {
    if (!companyId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setFetchError(null);
    try {
      const res = await apiRequest<unknown>(`/integration/customers/${companyId}`);
      setCustomers(parseCustomersPayload(res));
    } catch {
      setCustomers([]);
      setFetchError("Müşteriler yüklenemedi.");
    } finally {
      setLoading(false);
    }
  }, [companyId]);

  useEffect(() => {
    void fetchCustomers();
  }, [fetchCustomers]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter((c) =>
      [c.name, c.code, c.taxNo, c.phone, c.email].some((v) => v.toLowerCase().includes(q))
    );
  }, [customers, search]);

  const handleCreateSuccess = useCallback(async () => {
    if (!companyId) return;
    await fetchCustomers();
    try {
      const cmd = await sendCommand({
        company_id: companyId,
        command: "sync_customers",
        payload: {},
        send_to_all: true,
      });
      if (cmd.success) {
        setNotice({ ok: true, text: "Cari kaydedildi ve kasalara sync_customers komutu gönderildi." });
      } else {
        setNotice({
          ok: false,
          text: `Cari kaydedildi ancak komut gönderilemedi: ${cmd.message ?? "Bilinmeyen hata"}`,
        });
      }
    } catch {
      setNotice({
        ok: false,
        text: "Cari kaydedildi ancak sync_customers komutu gönderilemedi.",
      });
    }
  }, [companyId, fetchCustomers]);

  return (
    <div className="space-y-6">
      {showModal && companyId && (
        <AddCustomerModal
          companyId={companyId}
          onClose={() => setShowModal(false)}
          onSuccess={handleCreateSuccess}
        />
      )}

      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Müşteri / Cari</h1>
          <p className="mt-1 text-sm text-gray-500">
            Cari kayıtlarını görüntüleyin ve yeni müşteri ekleyin.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void fetchCustomers()}
            className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50"
          >
            Yenile
          </button>
          <button
            type="button"
            onClick={() => setShowModal(true)}
            disabled={!companyId}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50"
          >
            + Yeni Müşteri
          </button>
        </div>
      </div>

      {!companyId && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-700">
          Oturumda <strong>company_id</strong> bulunamadı. Lütfen tekrar giriş yapın.
        </div>
      )}

      {notice && (
        <div
          className={`rounded-lg border px-4 py-2.5 text-sm ${
            notice.ok
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-amber-200 bg-amber-50 text-amber-800"
          }`}
        >
          {notice.text}
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="flex items-center justify-between gap-4 border-b border-gray-100 px-5 py-4">
          <div className="relative w-80 max-w-full">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
              <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="İsim, kod, TC/VKN, telefon..."
              className="w-full rounded-lg border border-gray-200 py-2 pl-9 pr-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <span className="text-xs text-gray-400">{filtered.length} kayıt</span>
        </div>

        {loading ? (
          <p className="py-14 text-center text-sm text-gray-400">Yükleniyor...</p>
        ) : fetchError ? (
          <div className="space-y-2 py-14 text-center">
            <p className="text-sm text-red-500">{fetchError}</p>
            <button
              type="button"
              onClick={() => void fetchCustomers()}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700"
            >
              Yeniden dene
            </button>
          </div>
        ) : filtered.length === 0 ? (
          <p className="py-14 text-center text-sm text-gray-400">Kayıt bulunamadı.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/60">
                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Müşteri</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Kod</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">TC/VKN</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">İletişim</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">Şehir / İlçe</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-gray-50/50">
                    <td className="px-5 py-3.5">
                      <div className="font-medium text-gray-900">{c.name || "—"}</div>
                      <div className="mt-0.5 text-xs text-gray-400">
                        {c.isPerson ? "Bireysel" : "Kurumsal"}
                        {c.taxOffice ? ` · ${c.taxOffice}` : ""}
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs font-mono text-gray-700">{c.code || "—"}</td>
                    <td className="px-5 py-3.5 text-xs text-gray-700">{c.taxNo || "—"}</td>
                    <td className="px-5 py-3.5 text-xs text-gray-600">
                      {c.phone || "—"}
                      {c.email ? <span className="ml-2 text-gray-400">{c.email}</span> : null}
                    </td>
                    <td className="px-5 py-3.5 text-xs text-gray-600">
                      {c.city || "—"}
                      {c.district ? <span className="ml-1 text-gray-400">/ {c.district}</span> : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default withAuth(CustomersPage);
