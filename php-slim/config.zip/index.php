<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'vendor/autoload.php';
require 'config/db.php';



use Slim\Factory\AppFactory;

// ✅ Slim 4 için DI\Container olmadan çalışma
$app = AppFactory::create();

// ✅ CORS Middleware Dahil Et
$corsMiddleware = require __DIR__ . '/middleware/cors.php';
$app->add($corsMiddleware);

// ✅ Routing Middleware'i ekle
$app->addRoutingMiddleware();

// ✅ Hata Ayıklama Middleware'i ekle
$errorMiddleware = $app->addErrorMiddleware(true, true, true);


// ✅ Test Endpoint - Users tablosundaki verileri listele
$app->get('/', function ($request, $response) {
    $response->getBody()->write("Test<br>");

    try {
        $db = getDBConnection();
        $stmt = $db->prepare("SELECT id, name, email FROM users");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($users as $user) {
            $response->getBody()->write("ID: " . $user['id'] . " | Name: " . $user['name'] . " | Email: " . $user['email'] . "<br>");
        }
    } catch (Exception $e) {
        $response->getBody()->write("Veritabanı hatası: " . $e->getMessage());
    }

    return $response;
});
// ✅ Diğer endpointleri dahil et
$loginRoutes = require __DIR__ . '/routes/login.php';
$loginRoutes($app);


// ✅ Kullanıcı listeleme endpointini ekle
$usersRoutes = require __DIR__ . '/routes/user.php';
$usersRoutes($app);

$noteRoutes = require __DIR__ . '/routes/tasknote.php';
$noteRoutes($app);

$noteRoutes = require __DIR__ . '/routes/contract.php';
$noteRoutes($app);


$customerRoutes = require __DIR__ . '/routes/addtask.php';
$customerRoutes($app);

$netgsmRoutes = require __DIR__ . '/routes/netgsm.php';
$netgsmRoutes($app);

$taskRoutes = require __DIR__ . '/routes/task.php';
$taskRoutes($app);

// ✅ Slim Uygulamasını Çalıştır
$app->run();
