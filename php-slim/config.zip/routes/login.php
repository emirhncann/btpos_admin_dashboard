<?php
require_once __DIR__ . '/../config/db.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

return function ($app) {
    $app->post('/login', function (Request $request, Response $response) {
        try {
            // Gelen isteğin içeriğini al
            $contentType = $request->getHeaderLine('Content-Type');

            if (strpos($contentType, 'application/json') !== false) {
                $data = json_decode($request->getBody()->getContents(), true);
            } else {
                $data = $request->getParsedBody();
            }

            // Kullanıcı giriş bilgileri
            $username = $data['username'] ?? '';
            $password = $data['password'] ?? '';

            if (empty($username) || empty($password)) {
                $response->getBody()->write(json_encode([
                    "status" => "error",
                    "message" => "Kullanıcı adı ve şifre boş olamaz!"
                ]));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
            }

            // Veritabanı bağlantısını aç
            $db = getDBConnection();

            // Kullanıcıyı bul (E-posta, kullanıcı adı veya ID ile giriş yapılabilir)
            $stmt = $db->prepare("SELECT * FROM users WHERE name = ? OR email = ? OR id = ?");
            $stmt->execute([$username, $username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Kullanıcı bulunduysa şifreyi karşılaştır
            if ($user && $password === $user['password']) { 
                // Kullanıcı bilgilerini JSON olarak döndür
                $response->getBody()->write(json_encode([
                    "status" => "success",
                    "message" => "Giriş başarılı.",
                    "user" => [
                        "id" => $user['id'],
                        "name" => $user['name'],
                        "surname" => $user['surname'],
                        "fullName" => $user['name'] . " " . $user['surname'],
                        "phone" => $user['phone'],
                        "email" => $user['email'],
                        "created_by" => $user['created_by']
                    ]
                ]));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
            } else {
                $response->getBody()->write(json_encode([
                    "status" => "error",
                    "message" => "Geçersiz kullanıcı adı veya şifre!"
                ]));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(401);
            }
        } catch (Exception $e) {
            $response->getBody()->write(json_encode([
                "status" => "error",
                "message" => "Sunucu hatası: " . $e->getMessage()
            ]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    });
};
